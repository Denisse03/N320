// const quotes = fetch("https://api.quotable.io/quotes?limit=20")
//   .then((results) => {
//     console.log(results);
//     let quoteMsg = document.createElement("div");
//     document.getElementsByTagName("div")[0].innerHTML = results;
//     document.getElementsByTagName("body")[0].appendChild(quoteMsg);
//   })
//   .catch((error) => {
//     console.log("there was an error");
//   });
// console.log(results);

//another way

fetch("https://api.quotable.io/quotes?limit=20")
  .then((results) => {
    console.log("resolved", results);

    return results.json();
  })
  .then((data) => {
    let quotes = data.results;
    console.log("Quotes Data:", quotes);
    //document.getElementById("cards").innerHTML = data;

    for (let quote of quotes) {
      let author = quote.author;
      let content = quote.content;

      let divContainer = document.createElement("div");
      console.log(divContainer);
      divContainer.classList.add("container");

      let divQuote = document.createElement("div");
      divQuote.classList.add("quote");

      let divAuthor = document.createElement("div");
      divAuthor.classList.add("author");

      divAuthor.innerHTML = author;
      divQuote.innerHTML = content;

      divContainer.appendChild(divQuote);

      divContainer.appendChild(divAuthor);

      document.body.appendChild(divContainer);
    }
  })
  .catch((error) => {
    console.log("rejected", error);
  });
