<template>
      <h1>Teams</h1>

      
      
</template>

<script></script>