const quotes = new Promise((resolve, reject) => {
  const response = fetch("https://api.quotable.io/quotes?limit=20");
  console.log(response);
  const results = response.json();
  console.log("results");
  return response.json();

  //   if (results != null){
  //     resolve(results)
  //   } else{}
});

quotes
  .then((data) => {
    console.log(data);
    let quoteMsg = document.createElement("div");
    quoteMsg.innerHTML = data.value;
    document.getElementsByTagName("body")[0].appendChild(quoteMsg);
  })
  .catch((error) => {
    console.log("there was an error");
  });
