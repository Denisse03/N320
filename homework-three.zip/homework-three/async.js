async function dogPhoto() {
  const response = await fetch("https://dog.ceo/api/breeds/image/random/20");

  const results = await response.json();

  return results.message;
  // dogImg(results);
}

// function dogImg(results) {
//   console.log(results);
//   console.log("results");
// }

dogPhoto().then((message) => {
  console.log(message);
  message.forEach((element) => {
    console.log(element);
    let dogPic = document.createElement("img");
    dogPic.src = element;
    document.getElementsByTagName("body")[0].appendChild(dogPic);
  });
  // let dogImg = document.getElementsByTagName("div")[0];
  // dogImg.innerHTML = message.value;
});
